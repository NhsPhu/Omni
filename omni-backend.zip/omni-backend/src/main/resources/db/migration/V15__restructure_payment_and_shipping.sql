-- Drop old tables if they conflict (from V5)
DROP TABLE IF EXISTS webhook_events CASCADE;
DROP TABLE IF EXISTS withdrawal_requests CASCADE;
DROP TABLE IF EXISTS system_commissions CASCADE;
DROP TABLE IF EXISTS wallet_transactions CASCADE;
DROP TABLE IF EXISTS wallets CASCADE;
DROP TABLE IF EXISTS order_status_history CASCADE;

-- ============================================================
-- PAYMENT MODULE
-- ============================================================

-- Admin wallet
CREATE TABLE IF NOT EXISTS admin_wallet (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    total_balance   BIGINT DEFAULT 0,
    pending_balance BIGINT DEFAULT 0,
    available_balance BIGINT DEFAULT 0,
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Vendor wallet
CREATE TABLE IF NOT EXISTS vendor_wallets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    shop_id           UUID UNIQUE NOT NULL REFERENCES shops(id),
    available_balance BIGINT DEFAULT 0,
    pending_balance   BIGINT DEFAULT 0,
    total_earned      BIGINT DEFAULT 0,
    updated_at TIMESTAMP DEFAULT NOW(),
    created_at TIMESTAMP DEFAULT NOW()
);

-- Ledger
CREATE TABLE IF NOT EXISTS wallet_transactions (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    wallet_type   VARCHAR(10) NOT NULL,
    wallet_id     UUID NOT NULL,
    shop_order_id UUID REFERENCES child_orders(id),
    order_id      UUID REFERENCES parent_orders(id),
    type          VARCHAR(30) NOT NULL,
    amount         BIGINT NOT NULL,
    balance_after  BIGINT NOT NULL,
    note           TEXT,
    created_at     TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_wallet_txn_wallet ON wallet_transactions(wallet_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_wallet_txn_shop_order ON wallet_transactions(shop_order_id);

-- Commission snapshots
CREATE TABLE IF NOT EXISTS commission_snapshots (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    shop_order_id    UUID UNIQUE NOT NULL REFERENCES child_orders(id),
    commission_rate  DECIMAL(5,4) NOT NULL,
    order_amount     BIGINT NOT NULL,
    commission_amount BIGINT NOT NULL,
    vendor_amount    BIGINT NOT NULL,
    settled_at       TIMESTAMP,
    created_at       TIMESTAMP DEFAULT NOW()
);

-- Withdrawal requests
CREATE TABLE IF NOT EXISTS withdrawal_requests (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    shop_id             UUID NOT NULL REFERENCES shops(id),
    wallet_id           UUID NOT NULL REFERENCES vendor_wallets(id),
    amount              BIGINT NOT NULL,
    bank_name           VARCHAR(100) NOT NULL,
    bank_account_number VARCHAR(50) NOT NULL,
    bank_account_name   VARCHAR(255) NOT NULL,
    status              VARCHAR(20) DEFAULT 'PENDING',
    admin_note          TEXT,
    approved_by         UUID REFERENCES users(id),
    approved_at         TIMESTAMP,
    created_at          TIMESTAMP DEFAULT NOW(),
    updated_at          TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- SHIPPING / TRACKING MODULE
-- ============================================================

CREATE TABLE IF NOT EXISTS shipment_tracking (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    shop_order_id UUID NOT NULL REFERENCES child_orders(id),
    tracking_code VARCHAR(100) NOT NULL,
    ghn_status    VARCHAR(50) NOT NULL,
    status_name   VARCHAR(200),
    location      VARCHAR(500),
    note          TEXT,
    occurred_at   TIMESTAMP,
    received_at   TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_tracking_shop_order ON shipment_tracking(shop_order_id, occurred_at DESC);
CREATE INDEX IF NOT EXISTS idx_tracking_code ON shipment_tracking(tracking_code);

CREATE TABLE IF NOT EXISTS order_status_history (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    shop_order_id UUID NOT NULL REFERENCES child_orders(id),
    old_status    VARCHAR(30),
    new_status    VARCHAR(30) NOT NULL,
    changed_by    UUID REFERENCES users(id),
    actor         VARCHAR(20),
    note          TEXT,
    created_at    TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_status_history_order ON order_status_history(shop_order_id, created_at DESC);

CREATE TABLE IF NOT EXISTS delayed_jobs (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    job_type      VARCHAR(50) NOT NULL,
    payload       JSONB NOT NULL,
    execute_at    TIMESTAMP NOT NULL,
    status        VARCHAR(20) DEFAULT 'PENDING',
    attempts      INT DEFAULT 0,
    created_at    TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_delayed_jobs_execute ON delayed_jobs(execute_at, status);

CREATE TABLE IF NOT EXISTS ghn_address_cache (
    id           SERIAL PRIMARY KEY,
    type         VARCHAR(20) NOT NULL,
    ghn_id       VARCHAR(20) NOT NULL,
    parent_id    VARCHAR(20),
    name         VARCHAR(255) NOT NULL,
    UNIQUE(type, ghn_id)
);

-- Cột thêm vào bảng orders (parent_orders)
ALTER TABLE parent_orders ADD COLUMN IF NOT EXISTS idempotency_key VARCHAR(255) UNIQUE;
ALTER TABLE parent_orders ADD COLUMN IF NOT EXISTS vnpay_txn_ref VARCHAR(100);
ALTER TABLE parent_orders ADD COLUMN IF NOT EXISTS vnpay_bank_code VARCHAR(20);
ALTER TABLE parent_orders ADD COLUMN IF NOT EXISTS paid_at TIMESTAMP;

-- Cột thêm vào bảng shop_orders (child_orders)
ALTER TABLE child_orders ADD COLUMN IF NOT EXISTS tracking_code VARCHAR(100);
ALTER TABLE child_orders ADD COLUMN IF NOT EXISTS ghn_order_code VARCHAR(100);
ALTER TABLE child_orders ADD COLUMN IF NOT EXISTS shipped_at TIMESTAMP;
ALTER TABLE child_orders ADD COLUMN IF NOT EXISTS delivered_at TIMESTAMP;
ALTER TABLE child_orders ADD COLUMN IF NOT EXISTS completed_at TIMESTAMP;
ALTER TABLE child_orders ADD COLUMN IF NOT EXISTS cancelled_at TIMESTAMP;
ALTER TABLE child_orders ADD COLUMN IF NOT EXISTS cancel_reason TEXT;
ALTER TABLE child_orders ADD COLUMN IF NOT EXISTS auto_complete_at TIMESTAMP;
