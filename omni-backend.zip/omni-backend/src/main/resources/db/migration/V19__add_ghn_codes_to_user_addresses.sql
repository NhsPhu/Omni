ALTER TABLE user_addresses
ADD COLUMN ghn_province_id INT,
ADD COLUMN ghn_district_id INT,
ADD COLUMN ghn_ward_code VARCHAR(20);
