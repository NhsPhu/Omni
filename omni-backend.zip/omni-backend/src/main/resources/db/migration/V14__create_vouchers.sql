CREATE TABLE IF NOT EXISTS vouchers (
    id UUID PRIMARY KEY,
    code VARCHAR(50) UNIQUE NOT NULL,
    description VARCHAR(255),
    discount_percent DECIMAL(5,2) NOT NULL,
    max_discount_amount DECIMAL(12,2),
    min_order_value DECIMAL(12,2) NOT NULL DEFAULT 0,
    shop_id UUID, -- If null, it's a platform voucher
    expiry_date TIMESTAMP WITH TIME ZONE NOT NULL,
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Seed some vouchers for testing
INSERT INTO vouchers (id, code, description, discount_percent, max_discount_amount, min_order_value, expiry_date, active)
VALUES 
('11111111-1111-1111-1111-111111111111', 'OMNI2026', 'Giảm 10% toàn sàn', 10.00, 50000.00, 100000.00, '2026-12-31 23:59:59+00', TRUE),
('22222222-2222-2222-2222-222222222222', 'WELCOME50', 'Giảm 50% cho người mới', 50.00, 100000.00, 0.00, '2026-12-31 23:59:59+00', TRUE);
